Qicko / RuStore kit 1.4 (5)

Upload only android/releases/PortalBooks-1.4-rustore.apk.
Read docs/RUSTORE.md for compilation and publication steps.
No private signing key or password is included. Keep the owner key for future updates.
Android SDK verifies the signed artifact during assembleRuStore; this packaging step checks the exported report and hashes.
This archive has not been submitted to RuStore and does not guarantee moderation approval.

Pending manual fields: age_rating, category (select an actual category in RuStore Console), developer, support_email
